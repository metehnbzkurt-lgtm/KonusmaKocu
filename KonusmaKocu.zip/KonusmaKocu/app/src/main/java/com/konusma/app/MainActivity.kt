package com.konusma.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("tr", "TR") }
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        setContent { MaterialTheme { App(prefs) { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "x") } } }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(prefs: SharedPreferences, speak: (String) -> Unit) {
    var cat by remember { mutableStateOf<Category?>(null) }
    var lesson by remember { mutableStateOf<Lesson?>(null) }
    var done by remember { mutableStateOf(prefs.getStringSet("d", emptySet())!!.toSet()) }
    BackHandler(cat != null) { if (lesson != null) lesson = null else cat = null }
    fun key(c: Category, l: Lesson, i: Int) = "${c.name}|${l.title}|$i"
    Scaffold(topBar = { TopAppBar(title = { Text(lesson?.title ?: cat?.name ?: "Konuşma Koçu") }) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val c = cat; val l = lesson
            if (c == null) {
                items(CATEGORIES) { k ->
                    val total = k.lessons.sumOf { it.phrases.size }
                    val n = done.count { it.startsWith(k.name + "|") }
                    Card(Modifier.fillMaxWidth().clickable { cat = k }) {
                        Text("${k.emoji} ${k.name}\n$n / $total söylendi", Modifier.padding(16.dp), fontSize = 18.sp)
                    }
                }
            } else if (l == null) {
                items(c.lessons) { x ->
                    Card(Modifier.fillMaxWidth().clickable { lesson = x }) {
                        Column(Modifier.padding(16.dp)) {
                            Text(x.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(x.situation)
                        }
                    }
                }
            } else {
                item { Text("Durum: ${l.situation}\nCümleyi dinle, yüksek sesle söyle, sonra işaretle.") }
                items(l.phrases.indices.toList()) { i ->
                    val p = l.phrases[i]; val k = key(c, l, i)
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(p.tone, color = MaterialTheme.colorScheme.primary)
                            Text(p.say, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            if (p.note.isNotEmpty()) Text(p.note)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { speak(p.say) }) { Text("🔊 Dinle") }
                                OutlinedButton(onClick = {
                                    done = if (k in done) done - k else done + k
                                    prefs.edit().putStringSet("d", done).apply()
                                }) { Text(if (k in done) "✓ Söyledim" else "Söyledim") }
                            }
                        }
                    }
                }
            }
        }
    }
}
