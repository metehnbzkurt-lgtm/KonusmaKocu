package com.konusma.app

data class Phrase(val say: String, val tone: String, val note: String = "")
data class Lesson(val title: String, val situation: String, val phrases: List<Phrase>)
data class Category(val emoji: String, val name: String, val lessons: List<Lesson>)

val CATEGORIES = listOf(
 Category("🙏", "Nezaket Temeli", listOf(
  Lesson("Teşekkür ve rica", "Biri sana yardım etti ya da bir şey verdi.", listOf(
   Phrase("Teşekkür ederim.", "Günlük/resmi", "En güvenli kalıp; her yerde kullanılır."),
   Phrase("Sağ ol!", "Samimi", "Arkadaş, akraba, yaşıtlar için."),
   Phrase("Çok teşekkürler, çok yardımcı oldunuz.", "Resmi", "Hastane, banka, iş yeri."),
   Phrase("Rica ederim.", "Günlük/resmi", "Teşekkür edene cevap.")) ),
  Lesson("Özür ve dikkat çekme", "Birine çarptın, ya da konuşmaya başlamak istiyorsun.", listOf(
   Phrase("Pardon!", "Günlük", "Çarpınca, yol isterken."),
   Phrase("Affedersiniz, bir şey sorabilir miyim?", "Resmi", "Yabancıya soru sormadan önce."),
   Phrase("Özür dilerim, yanlış anladım.", "Resmi", "Hata yapınca kısa ve net özür."),
   Phrase("Önemli değil, sorun değil.", "Günlük", "Özre cevap."))),
  Lesson("Tekrar ve anlamadım", "Karşıdakini duymadın ya da anlamadın.", listOf(
   Phrase("Pardon, anlayamadım. Tekrar eder misiniz?", "Resmi"),
   Phrase("Efendim?", "Günlük", "Duyamadığında kısa ve kibar."),
   Phrase("Biraz yavaş konuşabilir misiniz?", "Resmi"),
   Phrase("Bir saniye düşüneyim.", "Günlük", "Cevap bulamayınca zaman kazanır."))))),
 Category("🏷️", "Hitap Şekilleri", listOf(
  Lesson("Kime nasıl seslenilir", "Karşındakine ne diyeceğini bilmiyorsun.", listOf(
   Phrase("Merhaba Ahmet Bey / Ayşe Hanım.", "Resmi", "Ad + Bey/Hanım: iş ve resmi yerlerde en doğrusu."),
   Phrase("Merhaba hocam.", "Yarı resmi", "Öğretmen, usta, doktor, amir için sıcak ve saygılı."),
   Phrase("Abi / Abla", "Samimi", "Esnaf, garson, kurye, tanıdık yaşça büyükler. İş görüşmesinde kullanma."),
   Phrase("Amca / Teyze", "Samimi", "Yaşlı yabancılara saygılı hitap."),
   Phrase("Efendim, buyurun.", "Resmi", "Çağrılınca ya da yardım sunarken."),
   Phrase("Sayın Müdürüm / Sayın Yetkili", "Çok resmi", "Dilekçe, e-posta, resmi daire."))))),
 Category("💬", "Karşı Cinsle Konuşma", listOf(
  Lesson("Selam ve ilk cümle", "Tanımadığın biriyle ya da yeni biriyle konuşmaya başlıyorsun.", listOf(
   Phrase("Merhaba, nasılsınız?", "Resmi", "Göz teması 1-2 saniye, hafif gülümseme yeterli."),
   Phrase("Selam, ben Ali. Memnun oldum.", "Günlük", "Kendini tanıtmak konuşmayı kolaylaştırır."),
   Phrase("Bu ortam nasıl, daha önce geldiniz mi?", "Günlük", "Ortamla ilgili soru en rahat başlangıçtır."),
   Phrase("Bugün günün nasıl geçti?", "Samimi", "Tanıdıkla sıcak sohbet.")),),
  Lesson("Takılma anı ve sohbeti bitirme", "Söyleyecek şey bulamadın ya da kapatmak istiyorsun.", listOf(
   Phrase("Hmm, ilginç. Peki sen ne düşünüyorsun?", "Günlük", "Soruyu karşıya çevir; sessizlik azalır."),
   Phrase("Bir saniye, aklımdakini toparlayayım.", "Günlük", "Takılmayı doğal gösterir."),
   Phrase("Seninle konuşmak güzeldi, görüşürüz.", "Günlük", "Nazik kapanış."),
   Phrase("İyi günler, kolay gelsin.", "Resmi", "Her ortamda güvenli kapanış."))))),
 Category("🚌", "Toplu Taşıma", listOf(
  Lesson("İnmek için yol isteme", "Kapıya gidip inmen gerekiyor, önünde kişiler var.", listOf(
   Phrase("Pardon, inecek var.", "Günlük", "En kısa ve yaygın."),
   Phrase("Affedersiniz, bir sonrakinde ineceğim, geçebilir miyim?", "Resmi", "Kadın-erkek fark etmez, aynı kalıp."),
   Phrase("Müsaade eder misiniz?", "Resmi", "Kibar ve kısa."),
   Phrase("Teşekkür ederim, iyi günler.", "Günlük", "İndikten/geçtikten sonra.")),),
  Lesson("Yer verme, durak sorma", "Birine yer vermek ya da durak öğrenmek istiyorsun.", listOf(
   Phrase("Buyurun, oturabilirsiniz.", "Resmi", "Yaşlı, hamile, engelli yolcuya."),
   Phrase("Affedersiniz, bu otobüs Kadıköy'e gider mi?", "Resmi"),
   Phrase("Pardon, şu an hangi duraktayız?", "Günlük"),
   Phrase("Şoför bey, bir sonraki durakta inebilir miyim?", "Resmi"))))),
 Category("🛒", "Alışveriş", listOf(
  Lesson("Mağaza ve market", "Bir şey arıyorsun ya da ödeme yapacaksın.", listOf(
   Phrase("Merhaba, şunu arıyorum: ...", "Günlük"),
   Phrase("Bunun fiyatı nedir?", "Resmi"),
   Phrase("Biraz bakıyorum, teşekkür ederim.", "Günlük", "Satıcı yardım teklif edince baskı hissetmeden cevap."),
   Phrase("Bunun başka bedeni / rengi var mı?", "Günlük"),
   Phrase("Kartla ödeyebilir miyim?", "Günlük"),
   Phrase("Değişim yapmak istiyorum, fişim burada.", "Resmi"))))),
 Category("📞", "Telefon", listOf(
  Lesson("Arama ve cevap", "Telefonda konuşuyorsun.", listOf(
   Phrase("Alo, merhaba. Ben Ali Yılmaz.", "Günlük", "Aradığında önce kendini söyle."),
   Phrase("İyi günler, randevu almak istiyorum.", "Resmi"),
   Phrase("Müsaitseniz birkaç dakika konuşabilir miyiz?", "Resmi"),
   Phrase("Pardon, sesiniz kesiliyor, tekrar eder misiniz?", "Günlük"),
   Phrase("Teşekkür ederim, iyi günler dilerim.", "Resmi", "Kapanışta."))))),
 Category("🏥", "Hastane", listOf(
  Lesson("Kayıt ve doktor", "Randevuya gidiyorsun.", listOf(
   Phrase("İyi günler, saat 14:00'te randevum var.", "Resmi"),
   Phrase("Kimlik kartımı vereyim mi?", "Resmi"),
   Phrase("Doktor bey/hanım, şikâyetim şu: ...", "Resmi", "Önce ana derdini söyle, sonra ayrıntı ver."),
   Phrase("İlacı nasıl kullanmam gerekiyor?", "Resmi", "Anlamadığını sormak normaldir."),
   Phrase("Geçmiş olsun.", "Günlük", "Hasta birine."))))),
 Category("💼", "İş Yeri", listOf(
  Lesson("Amir ve iş arkadaşı", "İşte günlük konuşmalar.", listOf(
   Phrase("Günaydın, kolay gelsin.", "Günlük", "Gün başı ve karşılaşmalarda."),
   Phrase("Müsait misiniz? Size iki dakika danışabilir miyim?", "Resmi"),
   Phrase("Bunu anladım, şu kısmı netleştirebilir miyiz?", "Resmi", "Anlamadığını profesyonel şekilde söyleme."),
   Phrase("Elimden geleni yapacağım, yarın akşama kadar hazır olur.", "Resmi"),
   Phrase("İyi akşamlar, yarın görüşürüz.", "Günlük"))))),
 Category("🏛️", "Resmi Daire", listOf(
  Lesson("Dilekçe ve işlem", "Belediye, nüfus, banka gibi yerler.", listOf(
   Phrase("İyi günler, nüfus cüzdanı işlemi için geldim.", "Çok resmi"),
   Phrase("Sıra numarası nereden alınır?", "Resmi"),
   Phrase("Hangi evrakları getirmem gerekiyor?", "Resmi"),
   Phrase("Çok teşekkür ederim, zahmet verdim.", "Resmi"))))))
